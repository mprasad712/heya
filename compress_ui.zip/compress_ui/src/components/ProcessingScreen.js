import React, { useState, useEffect } from 'react';

const STEPS = [
  { label: 'Document Ingestion', description: 'Reading and parsing file data...' },
  { label: 'NLP Analysis', description: 'Extracting process metadata with GPT-4...' },
  { label: '7-Metric Scoring', description: 'Running proprietary scoring algorithm...' },
  { label: 'Output Generation', description: 'Generating assessment results...' },
];

const ProcessingScreen = ({ fileName, fileType }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    // Step transitions at ~3.5s intervals across 15s total
    const stepTimings = [0, 3500, 7000, 11000];

    const timers = stepTimings.map((delay, index) =>
      setTimeout(() => setCurrentStep(index), delay)
    );

    // Smooth progress bar
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) return 100;
        return prev + 0.7;
      });
    }, 100);

    return () => {
      timers.forEach(clearTimeout);
      clearInterval(progressInterval);
    };
  }, []);

  const getStepStatus = (index) => {
    if (index < currentStep) return 'done';
    if (index === currentStep) return 'active';
    return 'pending';
  };

  return (
    <div className="processing-overlay">
      <div className="processing-content fade-in">
        <div className="processing-animation">
          <div className="processing-ring" />
          <div className="processing-ring-inner" />
        </div>

        <h2>Analyzing Process Document</h2>
        <p>
          Processing <strong>{fileName}</strong> ({fileType})
        </p>

        <div className="processing-steps">
          {STEPS.map((step, index) => (
            <div key={index} className={`processing-step ${getStepStatus(index)}`}>
              <div className="step-icon">
                {getStepStatus(index) === 'done' ? '✓' : index + 1}
              </div>
              <div>
                <div style={{ fontWeight: 600 }}>{step.label}</div>
                <div style={{ fontSize: '12px', opacity: 0.7, marginTop: '2px' }}>
                  {step.description}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="processing-progress">
          <div className="progress-bar-bg">
            <div
              className="progress-bar-fill"
              style={{ width: `${Math.min(progress, 100)}%` }}
            />
          </div>
          <div className="progress-text">
            {Math.min(Math.round(progress), 100)}% complete
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProcessingScreen;
