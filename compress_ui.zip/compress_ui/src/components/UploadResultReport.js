import React, { useState } from 'react';

const METRIC_COLORS = ['#e87722', '#0ea5e9', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899'];

const getTierLabel = (tier) => {
  switch (tier) {
    case 1: return 'Tier 1 - Quick Win';
    case 2: return 'Tier 2 - Standard';
    case 3: return 'Tier 3 - Complex';
    default: return 'Unclassified';
  }
};

const getScoreClass = (score) => {
  if (score >= 80) return 'high';
  if (score >= 60) return 'medium';
  return 'low';
};

const buildExportObj = (r) => ({
  process_id: r.processId,
  process_name: r.processName,
  department: r.department,
  tier: r.tier,
  tier_label: getTierLabel(r.tier),
  ai_readiness_score: r.readinessScore,
  metrics: Object.fromEntries(r.metrics.map((m) => [m.label, m.value])),
  recommendation: r.recommendation,
});

const triggerDownload = (content, filename, mime) => {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
};

const UploadResultReport = ({ result, fileName, fileType, onAnalyzeAnother }) => {
  const [exportOpen, setExportOpen] = useState(false);

  const downloadJSON = () => {
    triggerDownload(JSON.stringify(buildExportObj(result), null, 2), `${result.processId}_result.json`, 'application/json');
    setExportOpen(false);
  };
  const downloadCSV = () => {
    const obj = buildExportObj(result);
    const flat = { ...obj, ...obj.metrics };
    delete flat.metrics;
    const h = Object.keys(flat).join(',');
    const v = Object.values(flat).map((x) => `"${x}"`).join(',');
    triggerDownload(`${h}\n${v}`, `${result.processId}_result.csv`, 'text/csv');
    setExportOpen(false);
  };
  const downloadXML = () => {
    const obj = buildExportObj(result);
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n<AssessmentResult>\n';
    const tag = (k, v) => { xml += `  <${k}>${v}</${k}>\n`; };
    tag('ProcessID', obj.process_id);
    tag('ProcessName', obj.process_name);
    tag('Department', obj.department);
    tag('Tier', obj.tier);
    tag('TierLabel', obj.tier_label);
    tag('AIReadinessScore', obj.ai_readiness_score);
    xml += '  <Metrics>\n';
    Object.entries(obj.metrics).forEach(([k, v]) => {
      xml += `    <${k.replace(/[^a-zA-Z]/g, '')}>${v}</${k.replace(/[^a-zA-Z]/g, '')}>\n`;
    });
    xml += '  </Metrics>\n';
    tag('Recommendation', obj.recommendation);
    xml += '</AssessmentResult>';
    triggerDownload(xml, `${result.processId}_result.xml`, 'application/xml');
    setExportOpen(false);
  };

  const scoreClass = getScoreClass(result.readinessScore);

  return (
    <div className="report fade-in">
      {/* Success banner */}
      <div className="report-banner">
        <div className="report-banner-left">
          <div className="report-success-icon">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12" />
            </svg>
          </div>
          <div>
            <h3>Analysis Complete</h3>
            <p>Processed <strong>{fileName}</strong> ({fileType})</p>
          </div>
        </div>
        <div className="report-banner-actions">
          <div className="report-export-wrap">
            <button className="report-export-btn" onClick={() => setExportOpen(!exportOpen)}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                <polyline points="7 10 12 15 17 10" />
                <line x1="12" y1="15" x2="12" y2="3" />
              </svg>
              Export
            </button>
            {exportOpen && (
              <div className="report-export-menu">
                <button onClick={downloadJSON}>JSON</button>
                <button onClick={downloadCSV}>CSV</button>
                <button onClick={downloadXML}>XML</button>
              </div>
            )}
          </div>
          <button className="report-new-btn" onClick={onAnalyzeAnother}>
            + Analyze Another
          </button>
        </div>
      </div>

      {/* Main report body */}
      <div className="report-body">
        {/* Left: score hero */}
        <div className="report-score-panel">
          <div className={`report-score-ring ${scoreClass}`}>
            <svg viewBox="0 0 120 120" className="report-ring-svg">
              <circle cx="60" cy="60" r="52" fill="none" stroke="#e5e7eb" strokeWidth="8" />
              <circle
                cx="60" cy="60" r="52"
                fill="none"
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={`${(result.readinessScore / 100) * 327} 327`}
                strokeDashoffset="0"
                transform="rotate(-90 60 60)"
                className={`ring-progress ${scoreClass}`}
              />
            </svg>
            <div className="report-score-text">
              <span className="report-score-num">{result.readinessScore}%</span>
              <span className="report-score-sub">AI Readiness</span>
            </div>
          </div>
          <div className={`report-tier-pill ${scoreClass}`}>
            {getTierLabel(result.tier)}
          </div>
        </div>

        {/* Right: details */}
        <div className="report-details">
          <div className="report-process-info">
            <h4>{result.processName}</h4>
            <span>{result.processId} | {result.department}</span>
          </div>

          {/* Metric bars — horizontal */}
          <div className="report-metrics">
            {result.metrics.map((m, i) => (
              <div key={i} className="report-metric-row">
                <span className="report-metric-name">{m.label}</span>
                <div className="report-metric-bar-wrap">
                  <div className="report-metric-bar-bg">
                    <div
                      className="report-metric-bar-fill"
                      style={{ width: `${(m.value / 5) * 100}%`, background: METRIC_COLORS[i] }}
                    />
                  </div>
                  <span className="report-metric-score" style={{ color: METRIC_COLORS[i] }}>{m.value}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recommendation */}
      <div className="report-recommendation">
        <div className="report-rec-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
          </svg>
        </div>
        <div>
          <span className="report-rec-title">Recommended Approach</span>
          <span className="report-rec-text">{result.recommendation}</span>
        </div>
      </div>
    </div>
  );
};

export default UploadResultReport;
