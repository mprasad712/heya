import React, { useState } from 'react';

const getTierLabel = (tier) => {
  switch (tier) {
    case 1: return 'Tier 1 - Quick Win';
    case 2: return 'Tier 2 - Standard';
    case 3: return 'Tier 3 - Complex';
    default: return 'Unclassified';
  }
};

const getTierClass = (tier) => `tier-${tier}`;

const getScoreClass = (score) => {
  if (score >= 80) return 'high';
  if (score >= 60) return 'medium';
  return 'low';
};

const buildResultObj = (r) => ({
  process_id: r.processId,
  process_name: r.processName,
  department: r.department,
  tier: r.tier,
  tier_label: getTierLabel(r.tier),
  ai_readiness_score: r.readinessScore,
  metrics: Object.fromEntries(r.metrics.map((m) => [m.label, m.value])),
  recommendation: r.recommendation,
});

const triggerDownload = (content, filename, mime) => {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
};

const ResultCard = ({ result, index = 0 }) => {
  const [downloadOpen, setDownloadOpen] = useState(false);

  const downloadJSON = () => {
    const data = JSON.stringify(buildResultObj(result), null, 2);
    triggerDownload(data, `${result.processId}_result.json`, 'application/json');
    setDownloadOpen(false);
  };

  const downloadCSV = () => {
    const obj = buildResultObj(result);
    const flat = { ...obj, ...obj.metrics };
    delete flat.metrics;
    const headers = Object.keys(flat).join(',');
    const values = Object.values(flat).map((v) => `"${v}"`).join(',');
    triggerDownload(`${headers}\n${values}`, `${result.processId}_result.csv`, 'text/csv');
    setDownloadOpen(false);
  };

  const downloadXML = () => {
    const obj = buildResultObj(result);
    let xml = '<?xml version="1.0" encoding="UTF-8"?>\n<AssessmentResult>\n';
    const addTag = (key, val) => { xml += `  <${key}>${val}</${key}>\n`; };
    addTag('ProcessID', obj.process_id);
    addTag('ProcessName', obj.process_name);
    addTag('Department', obj.department);
    addTag('Tier', obj.tier);
    addTag('TierLabel', obj.tier_label);
    addTag('AIReadinessScore', obj.ai_readiness_score);
    xml += '  <Metrics>\n';
    Object.entries(obj.metrics).forEach(([k, v]) => {
      xml += `    <${k.replace(/[^a-zA-Z]/g, '')}>${v}</${k.replace(/[^a-zA-Z]/g, '')}>\n`;
    });
    xml += '  </Metrics>\n';
    addTag('Recommendation', obj.recommendation);
    xml += '</AssessmentResult>';
    triggerDownload(xml, `${result.processId}_result.xml`, 'application/xml');
    setDownloadOpen(false);
  };

  return (
    <div className={`rc ${getTierClass(result.tier)} slide-in`} style={{ animationDelay: `${index * 0.08}s` }}>
      <div className="rc-top">
        <div>
          <span className={`tier-badge ${getTierClass(result.tier)}`}>{getTierLabel(result.tier)}</span>
          <h4 className="rc-title">{result.processName}</h4>
          <p className="rc-meta">{result.processId} | {result.department}</p>
        </div>
        <div className={`rc-score ${getScoreClass(result.readinessScore)}`}>
          <span className="rc-score-val">{result.readinessScore}%</span>
          <span className="rc-score-lbl">AI Readiness Score</span>
        </div>
      </div>

      <div className="rc-metrics">
        {result.metrics.map((metric, i) => (
          <div key={i} className="rc-metric">
            <div className="rc-metric-top">
              <span className="rc-metric-label">{metric.label.toUpperCase()}</span>
              <span className={`rc-metric-val color-${i}`}>{metric.value}/5</span>
            </div>
            <div className="rc-bar">
              <div className={`rc-bar-fill bar-${i}`} style={{ width: `${(metric.value / 5) * 100}%` }} />
            </div>
          </div>
        ))}
      </div>

      <div className="rc-footer">
        <div className={`rc-rec ${getTierClass(result.tier)}`}>
          <span className="rc-rec-label">Recommended:</span> {result.recommendation}
        </div>
        <div className="rc-download-wrap">
          <button
            className="rc-download-btn"
            onClick={() => setDownloadOpen(!downloadOpen)}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="7 10 12 15 17 10" />
              <line x1="12" y1="15" x2="12" y2="3" />
            </svg>
            Download
          </button>
          {downloadOpen && (
            <div className="rc-download-menu">
              <button onClick={downloadJSON}>
                <span className="dl-icon json">{ }</span> JSON
              </button>
              <button onClick={downloadCSV}>
                <span className="dl-icon csv">CSV</span> CSV
              </button>
              <button onClick={downloadXML}>
                <span className="dl-icon xml">&lt;/&gt;</span> XML
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export { getTierLabel, getTierClass, getScoreClass };
export default ResultCard;
