/**
 * Analyzes a parsed process document and returns scoring results.
 * Maps known process IDs to predefined scores for the POC demo.
 */

const KNOWN_PROCESSES = {
  'PR-FIN-042': {
    processName: 'Vendor Invoice Matching',
    processId: 'PR-FIN-042',
    department: 'Finance - Accounts Payable',
    tier: 1,
    readinessScore: 86,
    metrics: [
      { label: 'Automation', value: 4.5 },
      { label: 'Data Avail.', value: 4.0 },
      { label: 'Rule Stability', value: 4.8 },
      { label: 'Complexity', value: 3.5 },
      { label: 'Impact', value: 5.0 },
      { label: 'Strategic', value: 4.0 },
    ],
    recommendation: 'Hybrid AI Agent + iRPA | Deploy in Months 4-6',
  },
  'PR-HR-018': {
    processName: 'Employee Onboarding Verification',
    processId: 'PR-HR-018',
    department: 'HR Operations - GBS',
    tier: 2,
    readinessScore: 72,
    metrics: [
      { label: 'Automation', value: 3.8 },
      { label: 'Data Avail.', value: 3.5 },
      { label: 'Rule Stability', value: 4.0 },
      { label: 'Complexity', value: 3.2 },
      { label: 'Impact', value: 3.5 },
      { label: 'Strategic', value: 3.8 },
    ],
    recommendation: 'Document AI + Workflow Agent | Deploy in Months 7-9',
  },
};

/**
 * Generates a plausible score for unknown processes based on their data
 */
function generateScore(data) {
  const processId = data.Process_ID || data.process_id || 'UNKNOWN';
  const processName = data.Process_Name || data.process_name || 'Unknown Process';
  const department = data.Department || data.department || 'Unknown Department';
  const owner = data.Process_Owner || data.process_owner || '';

  // Derive some metrics from data characteristics
  const volume = parseInt(data.Volume || data.volume || '50');
  const fte = parseFloat(data.Current_FTE || data.FTE || data.fte || '1');
  const steps = data.Process_Steps?.length || parseInt(data.Steps || data.steps || '5');
  const errorRate = parseFloat((data.Error_Rate || data.error_rate || '10%').replace('%', ''));
  const exceptions = (data.Exceptions_Logged || data.Exceptions || data.exceptions || '').split(/[,|]/).filter(Boolean).length;

  // Calculate metrics (1-5 scale)
  const automation = Math.min(5, Math.max(2, 5 - (steps / 4) + (volume > 100 ? 1 : 0)));
  const dataAvail = Math.min(5, Math.max(2, 4 - (exceptions * 0.3) + (volume > 200 ? 0.5 : 0)));
  const ruleStability = Math.min(5, Math.max(2, 5 - (errorRate / 10)));
  const complexity = Math.min(5, Math.max(2, 5 - (steps / 3)));
  const impact = Math.min(5, Math.max(2, (fte * 1.2) + (volume > 100 ? 1 : 0)));
  const strategic = Math.min(5, Math.max(2, 3.5 + (volume > 200 ? 0.5 : 0)));

  const metrics = [
    { label: 'Automation', value: Math.round(automation * 10) / 10 },
    { label: 'Data Avail.', value: Math.round(dataAvail * 10) / 10 },
    { label: 'Rule Stability', value: Math.round(ruleStability * 10) / 10 },
    { label: 'Complexity', value: Math.round(complexity * 10) / 10 },
    { label: 'Impact', value: Math.round(impact * 10) / 10 },
    { label: 'Strategic', value: Math.round(strategic * 10) / 10 },
  ];

  const avgScore = metrics.reduce((sum, m) => sum + m.value, 0) / metrics.length;
  const readinessScore = Math.round((avgScore / 5) * 100);

  let tier, recommendation;
  if (readinessScore >= 80) {
    tier = 1;
    recommendation = `Hybrid AI Agent + iRPA | Deploy in Months 4-6`;
  } else if (readinessScore >= 60) {
    tier = 2;
    recommendation = `Document AI + Workflow Agent | Deploy in Months 7-9`;
  } else {
    tier = 3;
    recommendation = `Process Redesign + AI Assessment | Review in Months 10-12`;
  }

  return {
    processName,
    processId,
    department: `${department}${owner ? ' - ' + owner : ''}`,
    tier,
    readinessScore,
    metrics,
    recommendation,
  };
}

export function analyzeProcess(data, fileType) {
  // PDF uploads always map to Employee Onboarding
  if (fileType === 'PDF' || data._pdfFallback) {
    return { ...KNOWN_PROCESSES['PR-HR-018'] };
  }

  // Check for known process IDs first
  const processId = data.Process_ID || data.process_id || '';

  if (KNOWN_PROCESSES[processId]) {
    return { ...KNOWN_PROCESSES[processId] };
  }

  // For unknown processes, generate scores from data
  return generateScore(data);
}
