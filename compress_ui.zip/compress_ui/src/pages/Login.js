import React, { useState } from 'react';

const Login = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');

    if (email === 'manas.m.prasad@pwc.com' && password === '12345') {
      onLogin();
    } else {
      setError('Invalid credentials. Please check your email and password.');
    }
  };

  return (
    <div className="login-container">
      <div className="login-card fade-in">
        <div className="login-brand">
          <div className="login-brand-icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2a3 3 0 0 0-3 3c0 1.1.6 2 1.5 2.5V9H7a3 3 0 0 0-3 3c-.9.5-1.5 1.4-1.5 2.5a3 3 0 0 0 3 3h1v1.5c0 1.1.6 2 1.5 2.5a3 3 0 0 0 5 0c.9-.5 1.5-1.4 1.5-2.5V18h1a3 3 0 0 0 3-3c.9-.5 1.5-1.4 1.5-2.5a3 3 0 0 0-3-3h-3.5V7.5c.9-.5 1.5-1.4 1.5-2.5a3 3 0 0 0-3-3z" />
              <circle cx="12" cy="12" r="2" />
              <line x1="12" y1="10" x2="12" y2="7.5" />
              <line x1="12" y1="14" x2="12" y2="16.5" />
              <line x1="10" y1="12" x2="7" y2="12" />
              <line x1="14" y1="12" x2="17" y2="12" />
            </svg>
          </div>
          <h1>AI Readiness Assessment</h1>
          <p>Process Intelligence Platform</p>
        </div>

        <form className="login-form" onSubmit={handleSubmit}>
          {error && (
            <div className="login-error">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="12" cy="12" r="10" />
                <line x1="15" y1="9" x2="9" y2="15" />
                <line x1="9" y1="9" x2="15" y2="15" />
              </svg>
              {error}
            </div>
          )}

          <div className="form-group">
            <label>Email Address</label>
            <div className="form-input-wrapper">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="2" y="4" width="20" height="16" rx="2" />
                <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
              </svg>
              <input
                type="email"
                className="form-input"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label>Password</label>
            <div className="form-input-wrapper">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
                <path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
              <input
                type="password"
                className="form-input"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
          </div>

          <button type="submit" className="login-btn">
            Sign In
          </button>
        </form>

        <div className="login-footer">
          Powered by AI Readiness Assessment Engine v1.0
        </div>
      </div>
    </div>
  );
};

export default Login;
