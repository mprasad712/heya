import ResultCard from '../components/ResultCard';

const ResultsView = ({ results, onBack }) => {
  if (results.length === 0) {
    return (
      <div className="results-page fade-in">
        <div className="results-history">
          <h3>Assessment Results</h3>
          <div className="history-empty">
            <p>No results yet. Upload a process document to get started.</p>
          </div>
        </div>
      </div>
    );
  }

  const totalProcesses = results.length;
  const tier1Count = results.filter((r) => r.tier === 1).length;
  const tier2Count = results.filter((r) => r.tier === 2).length;
  const avgScore = Math.round(results.reduce((sum, r) => sum + r.readinessScore, 0) / totalProcesses);

  return (
    <div className="results-page fade-in">
      <div className="results-header">
        <h3>AI Agent Assessment Output</h3>
        <button className="back-btn" onClick={onBack}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="15 18 9 12 15 6" />
          </svg>
          Upload More
        </button>
      </div>

      <div className="results-summary-strip">
        <div className="strip-stat">
          <span className="strip-number">{totalProcesses.toLocaleString()}</span>
          <span className="strip-label">Processes Analyzed</span>
        </div>
        <div className="strip-divider" />
        <div className="strip-stat">
          <span className="strip-number">{tier1Count}</span>
          <span className="strip-label">Tier 1 Quick Wins</span>
        </div>
        <div className="strip-divider" />
        <div className="strip-stat">
          <span className="strip-number">{tier2Count}</span>
          <span className="strip-label">Tier 2 Candidates</span>
        </div>
        <div className="strip-divider" />
        <div className="strip-stat">
          <span className="strip-number">{avgScore}%</span>
          <span className="strip-label">Avg. Readiness Score</span>
        </div>
      </div>

      <div className="results-grid">
        {results.map((result, index) => (
          <ResultCard key={index} result={result} index={index} />
        ))}
      </div>
    </div>
  );
};

export default ResultsView;
