import React from 'react';

const DashboardHome = ({ results, onNavigate }) => {
  const totalProcesses = results.length;
  const tier1Count = results.filter((r) => r.tier === 1).length;
  const tier2Count = results.filter((r) => r.tier === 2).length;

  return (
    <div className="dashboard-home fade-in">
      {/* Hero banner */}
      <div className="dash-hero">
        <div className="dash-hero-text">
          <h2>AI Readiness Assessment Engine</h2>
          <p>Upload process documents to instantly evaluate automation potential using our proprietary 6-metric scoring model powered by LLMs.</p>
          <button className="dash-hero-btn" onClick={() => onNavigate('upload')}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
            Start Analysis
          </button>
        </div>
        <div className="dash-hero-visual">
          <div className="hero-ring">
            <svg viewBox="0 0 100 100">
              <circle cx="50" cy="50" r="42" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="6" />
              <circle cx="50" cy="50" r="42" fill="none" stroke="#e87722" strokeWidth="6" strokeLinecap="round"
                strokeDasharray="180 264" transform="rotate(-90 50 50)" />
            </svg>
            <div className="hero-ring-text">
              <span className="hero-ring-num">6</span>
              <span className="hero-ring-label">Metrics</span>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Stats — untouched */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-label">Processes Analyzed</div>
          <div className="stat-value">{totalProcesses > 0 ? totalProcesses.toLocaleString() : '—'}</div>
          <div className="stat-sub">Total uploaded</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Tier 1 Quick Wins</div>
          <div className="stat-value">{tier1Count > 0 ? tier1Count : '—'}</div>
          <div className="stat-sub">High automation potential</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Tier 2 Candidates</div>
          <div className="stat-value">{tier2Count > 0 ? tier2Count : '—'}</div>
          <div className="stat-sub">Standard automation</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Analysis Time</div>
          <div className="stat-value">{totalProcesses > 0 ? '15' : '—'}</div>
          <div className="stat-sub">{totalProcesses > 0 ? 'Seconds avg.' : 'No data yet'}</div>
        </div>
      </div>

      {/* Two-column: Pipeline + Supported Formats */}
      <div className="dash-two-col">
        <div className="how-it-works">
          <h3>Assessment Pipeline</h3>
          <div className="pipeline-list">
            <div className="pipeline-item">
              <div className="pipeline-num" style={{ background: 'rgba(232, 119, 34, 0.12)', color: '#e87722' }}>1</div>
              <div>
                <strong>Data Capture</strong>
                <p>Ingests structured process exports — JSON, XML, CSV, or PDF — via secure API integration.</p>
              </div>
            </div>
            <div className="pipeline-item">
              <div className="pipeline-num" style={{ background: 'rgba(14, 165, 233, 0.12)', color: '#0ea5e9' }}>2</div>
              <div>
                <strong>Intelligent Parsing</strong>
                <p>LLMs decompose each process into workflow steps, system dependencies, and exception paths.</p>
              </div>
            </div>
            <div className="pipeline-item">
              <div className="pipeline-num" style={{ background: 'rgba(16, 185, 129, 0.12)', color: '#10b981' }}>3</div>
              <div>
                <strong>Multi-Dimensional Scoring</strong>
                <p>Evaluates six dimensions: automation suitability, data readiness, rule stability, complexity, impact, and strategic fit.</p>
              </div>
            </div>
            <div className="pipeline-item">
              <div className="pipeline-num" style={{ background: 'rgba(139, 92, 246, 0.12)', color: '#8b5cf6' }}>4</div>
              <div>
                <strong>Insight Delivery</strong>
                <p>Results are visualized in dashboards and exportable as JSON, CSV, or XML for stakeholder review.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="dash-sidebar-panel">
          <div className="formats-card">
            <h4>Supported Formats</h4>
            <div className="format-chips">
              <span className="format-chip json">JSON</span>
              <span className="format-chip csv">CSV</span>
              <span className="format-chip xml">XML</span>
              <span className="format-chip pdf">PDF</span>
            </div>
          </div>
          <div className="tier-legend-card">
            <h4>Tier Classification</h4>
            <div className="tier-legend-items">
              <div className="tier-legend-row">
                <span className="tier-dot" style={{ background: '#10b981' }} />
                <div>
                  <strong>Tier 1 — Quick Win</strong>
                  <p>80%+ readiness, deploy in 4-6 months</p>
                </div>
              </div>
              <div className="tier-legend-row">
                <span className="tier-dot" style={{ background: '#0ea5e9' }} />
                <div>
                  <strong>Tier 2 — Standard</strong>
                  <p>60-79% readiness, deploy in 7-9 months</p>
                </div>
              </div>
              <div className="tier-legend-row">
                <span className="tier-dot" style={{ background: '#f59e0b' }} />
                <div>
                  <strong>Tier 3 — Complex</strong>
                  <p>Below 60%, requires redesign first</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Value Proposition */}
      <div className="value-prop">
        <h3>Why This Matters</h3>
        <div className="value-prop-grid">
          <div className="vp-card">
            <div className="vp-icon" style={{ background: 'rgba(239,68,68,0.1)', color: '#ef4444' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" /><polyline points="12 6 12 12 16 14" />
              </svg>
            </div>
            <strong>Manual Discovery</strong>
            <p>8-12 weeks of workshops, 200+ consultant hours to map and evaluate processes</p>
          </div>
          <div className="vp-card">
            <div className="vp-icon" style={{ background: 'rgba(232,119,34,0.1)', color: '#e87722' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
              </svg>
            </div>
            <strong>AI-Powered Analysis</strong>
            <p>Comparable depth in seconds with 95% scoring consistency and continuous learning</p>
          </div>
          <div className="vp-card">
            <div className="vp-icon" style={{ background: 'rgba(16,185,129,0.1)', color: '#10b981' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="23 6 13.5 15.5 8.5 10.5 1 18" /><polyline points="17 6 23 6 23 12" />
              </svg>
            </div>
            <strong>Accelerated ROI</strong>
            <p>Start building automation from Month 1, compressing the path to measurable returns</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardHome;
