import React, { useState } from 'react';
import DashboardHome from './DashboardHome';
import UploadFiles from './UploadFiles';
import ResultsView from './ResultsView';

const Dashboard = ({ onLogout }) => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activePage, setActivePage] = useState('dashboard');
  const [results, setResults] = useState([]);

  const handleAnalysisComplete = (result) => {
    setResults((prev) => [result, ...prev]);
  };

  const getPageTitle = () => {
    switch (activePage) {
      case 'dashboard': return 'Dashboard';
      case 'upload': return 'Upload Files';
      case 'results': return 'Assessment Results';
      default: return 'Dashboard';
    }
  };

  return (
    <div className="dashboard-layout">
      {/* Sidebar */}
      <aside className={`sidebar ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <div className="sidebar-header">
          <div className="sidebar-logo">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 2a3 3 0 0 0-3 3c0 1.1.6 2 1.5 2.5V9H7a3 3 0 0 0-3 3c-.9.5-1.5 1.4-1.5 2.5a3 3 0 0 0 3 3h1v1.5c0 1.1.6 2 1.5 2.5a3 3 0 0 0 5 0c.9-.5 1.5-1.4 1.5-2.5V18h1a3 3 0 0 0 3-3c.9-.5 1.5-1.4 1.5-2.5a3 3 0 0 0-3-3h-3.5V7.5c.9-.5 1.5-1.4 1.5-2.5a3 3 0 0 0-3-3z" />
              <circle cx="12" cy="12" r="2" />
              <line x1="12" y1="10" x2="12" y2="7.5" />
              <line x1="12" y1="14" x2="12" y2="16.5" />
              <line x1="10" y1="12" x2="7" y2="12" />
              <line x1="14" y1="12" x2="17" y2="12" />
            </svg>
          </div>
          {!sidebarCollapsed && (
            <div className="sidebar-title">
              AI <span>Readiness</span>
            </div>
          )}
        </div>

        <div
          className="sidebar-toggle"
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {sidebarCollapsed ? (
              <polyline points="9 18 15 12 9 6" />
            ) : (
              <polyline points="15 18 9 12 15 6" />
            )}
          </svg>
        </div>

        <nav className="sidebar-nav">
          <div
            className={`nav-item ${activePage === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActivePage('dashboard')}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <rect x="3" y="3" width="7" height="7" />
              <rect x="14" y="3" width="7" height="7" />
              <rect x="14" y="14" width="7" height="7" />
              <rect x="3" y="14" width="7" height="7" />
            </svg>
            {!sidebarCollapsed && <span>Dashboard</span>}
          </div>

          <div
            className={`nav-item ${activePage === 'upload' ? 'active' : ''}`}
            onClick={() => setActivePage('upload')}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
            {!sidebarCollapsed && <span>Upload Files</span>}
          </div>

          <div
            className={`nav-item ${activePage === 'results' ? 'active' : ''}`}
            onClick={() => setActivePage('results')}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
            </svg>
            {!sidebarCollapsed && <span>Results</span>}
          </div>
        </nav>

        <div className="sidebar-footer">
          <div className="nav-item logout" onClick={onLogout}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
              <polyline points="16 17 21 12 16 7" />
              <line x1="21" y1="12" x2="9" y2="12" />
            </svg>
            {!sidebarCollapsed && <span>Logout</span>}
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`main-content ${sidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
        <div className="topbar">
          <h2>{getPageTitle()}</h2>
          <div className="topbar-user">
            <span>manas.m.prasad@pwc.com</span>
            <div className="topbar-avatar">MP</div>
          </div>
        </div>

        <div className="page-content">
          {activePage === 'dashboard' && (
            <DashboardHome
              results={results}
              onNavigate={setActivePage}
            />
          )}
          {activePage === 'upload' && (
            <UploadFiles onAnalysisComplete={handleAnalysisComplete} />
          )}
          {activePage === 'results' && (
            <ResultsView
              results={results}
              onBack={() => setActivePage('upload')}
            />
          )}
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
