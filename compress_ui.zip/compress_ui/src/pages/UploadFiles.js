import React, { useState, useRef } from 'react';
import ProcessingScreen from '../components/ProcessingScreen';
import UploadResultReport from '../components/UploadResultReport';
import { analyzeProcess } from '../utils/analyzer';
import { parseCSV } from '../utils/csvParser';

const FILE_TYPES = ['JSON', 'CSV', 'XML', 'PDF'];

const UploadFiles = ({ onAnalysisComplete }) => {
  const [selectedType, setSelectedType] = useState('');
  const [file, setFile] = useState(null);
  const [dragging, setDragging] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [currentResult, setCurrentResult] = useState(null);
  const [fileName, setFileName] = useState('');
  const fileInputRef = useRef(null);

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragging(true);
  };

  const handleDragLeave = () => setDragging(false);

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      setFile(droppedFile);
      setCurrentResult(null);
      const ext = droppedFile.name.split('.').pop().toUpperCase();
      if (FILE_TYPES.includes(ext)) setSelectedType(ext);
    }
  };

  const handleFileSelect = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setCurrentResult(null);
      const ext = selectedFile.name.split('.').pop().toUpperCase();
      if (FILE_TYPES.includes(ext)) setSelectedType(ext);
    }
  };

  const parseFile = (fileContent) => {
    if (selectedType === 'JSON') {
      try {
        return JSON.parse(fileContent);
      } catch {
        return null;
      }
    } else if (selectedType === 'CSV') {
      const rows = parseCSV(fileContent);
      if (rows && rows.length > 0) {
        return rows[0];
      }
      return null;
    } else if (selectedType === 'XML') {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(fileContent, 'text/xml');
      const processId = xmlDoc.querySelector('Process_ID')?.textContent || '';
      const processName = xmlDoc.querySelector('Process_Name')?.textContent || '';
      const department = xmlDoc.querySelector('Department')?.textContent || '';
      const processOwner = xmlDoc.querySelector('Process_Owner')?.textContent || '';
      const volume = xmlDoc.querySelector('Volume')?.textContent || '0';
      const fte = xmlDoc.querySelector('Current_FTE')?.textContent || '0';
      const steps = xmlDoc.querySelectorAll('Step');
      const exceptions = xmlDoc.querySelector('Exceptions_Logged')?.textContent || '';
      const errorRate = xmlDoc.querySelector('Error_Rate')?.textContent || '0%';
      const systems = [];
      xmlDoc.querySelectorAll('Systems_Referenced > System').forEach(s => systems.push(s.textContent));

      return {
        Process_ID: processId,
        Process_Name: processName,
        Department: department,
        Process_Owner: processOwner,
        Volume: parseInt(volume),
        Current_FTE: parseFloat(fte),
        Process_Steps: Array.from(steps).map((s, i) => ({ Step: i + 1 })),
        Exceptions_Logged: exceptions,
        Error_Rate: errorRate,
        Systems_Referenced: systems,
        Steps: steps.length.toString()
      };
    } else if (selectedType === 'PDF') {
      // PDF: return marker for Employee Onboarding
      return { _pdfFallback: true, Process_ID: 'PR-HR-018' };
    }
    return null;
  };

  const handleUpload = () => {
    if (!file || !selectedType) return;

    setProcessing(true);
    setCurrentResult(null);
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target.result;
      const parsed = parseFile(content);

      if (!parsed) {
        setProcessing(false);
        alert('Could not parse the file. Please check the format.');
        return;
      }

      setTimeout(() => {
        const result = analyzeProcess(parsed, selectedType);
        setProcessing(false);
        setCurrentResult(result);
        onAnalysisComplete(result);
      }, 15000);
    };

    if (selectedType === 'PDF') {
      // For PDF we don't need to actually read the text — just trigger the fallback
      reader.onload({ target: { result: '' } });
    } else {
      reader.readAsText(file);
    }
  };

  const handleAnalyzeAnother = () => {
    setCurrentResult(null);
    setFile(null);
    setFileName('');
    setSelectedType('');
  };

  if (processing) {
    return <ProcessingScreen fileName={file?.name} fileType={selectedType} />;
  }

  if (currentResult) {
    return (
      <UploadResultReport
        result={currentResult}
        fileName={fileName}
        fileType={selectedType}
        onAnalyzeAnother={handleAnalyzeAnother}
      />
    );
  }

  return (
    <div className="upload-layout fade-in">
      {/* Main upload area */}
      <div className="upload-card">
        <h3>Upload Process Document</h3>
        <p>Select the file type and upload your ADONIS process export for AI readiness analysis.</p>

        <div className="file-type-selector">
          <label>Select File Type</label>
          <div className="file-type-options">
            {FILE_TYPES.map((type) => (
              <button
                key={type}
                className={`file-type-btn ${selectedType === type ? 'selected' : ''}`}
                onClick={() => setSelectedType(type)}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        <div
          className={`drop-zone ${dragging ? 'dragging' : ''}`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            accept={selectedType ? `.${selectedType.toLowerCase()}` : '.json,.csv,.xml,.pdf'}
            style={{ display: 'none' }}
          />
          <div className="drop-zone-icon">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
              <polyline points="17 8 12 3 7 8" />
              <line x1="12" y1="3" x2="12" y2="15" />
            </svg>
          </div>
          <h4>Drag & drop your file here</h4>
          <p>or <span className="browse-link">browse</span> to choose a file</p>
        </div>

        {file && (
          <div className="selected-file">
            <span>📄 {file.name} ({(file.size / 1024).toFixed(1)} KB)</span>
            <button onClick={(e) => { e.stopPropagation(); setFile(null); }}>✕</button>
          </div>
        )}

        <button
          className="upload-btn"
          onClick={handleUpload}
          disabled={!file || !selectedType}
        >
          Analyze Process
        </button>
      </div>

      {/* Right sidebar info */}
      <div className="upload-info-panel">
        <div className="upload-info-card">
          <div className="upload-info-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10" /><path d="M12 16v-4" /><path d="M12 8h.01" />
            </svg>
          </div>
          <h4>How It Works</h4>
          <ol className="upload-info-steps">
            <li>Select a file format (JSON, CSV, XML, or PDF)</li>
            <li>Upload your process export document</li>
            <li>AI engine analyzes and scores the process</li>
            <li>Review results with 6-metric breakdown</li>
          </ol>
        </div>

        <div className="upload-info-card">
          <div className="upload-info-icon green">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" />
            </svg>
          </div>
          <h4>What Gets Evaluated</h4>
          <div className="upload-metric-list">
            <span>Automation Suitability</span>
            <span>Data Availability</span>
            <span>Rule Stability</span>
            <span>Process Complexity</span>
            <span>Business Impact</span>
            <span>Strategic Alignment</span>
          </div>
        </div>

        <div className="upload-info-card dark">
          <strong>Pro Tip</strong>
          <p>For best results, ensure your process document includes step details, exception types, volume data, and system references.</p>
        </div>
      </div>
    </div>
  );
};

export default UploadFiles;
